// sw.js
let audioContext;
let audioBuffer;
let sourceNode;

self.addEventListener('install', (event) => {
    self.skipWaiting();
});

self.addEventListener('activate', (event) => {
    event.waitUntil(self.clients.claim());
});

self.addEventListener('message', (event) => {
    if (event.data === 'playAudio') {
        playAudio();
    }
});

async function playAudio() {
    if (!audioContext) {
        audioContext = new AudioContext();
        const response = await fetch('sound/Avalon - Taku Iwasaki.mp3');
        audioBuffer = await audioContext.decodeAudioData(await response.arrayBuffer());
    }
    
    if (!sourceNode) {
        sourceNode = audioContext.createBufferSource();
        sourceNode.buffer = audioBuffer;
        sourceNode.loop = true;
        sourceNode.connect(audioContext.destination);
        sourceNode.start();
    }
}