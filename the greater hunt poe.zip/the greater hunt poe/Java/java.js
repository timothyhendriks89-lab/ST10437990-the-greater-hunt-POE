// =============================
// ELDEN RING POPUP SYSTEM
// =============================

class EldenPopup {
    constructor() {
        this.container = null;
        this.init();
    }

    init() {
        this.container = document.createElement('div');
        this.container.className = 'elden-popup-container';
        document.body.appendChild(this.container);
    }

    show(title, message, duration = 4000) {
        const popup = document.createElement('div');
        popup.className = 'elden-popup';
        popup.innerHTML = `
            <button class="elden-popup-close">×</button>
            <div class="elden-popup-title">${title}</div>
            <div class="elden-popup-message">${message}</div>
        `;

        const closeBtn = popup.querySelector('.elden-popup-close');
        
        const closePopup = () => {
            popup.style.animation = 'eldenSlideOut 0.3s ease-out';
            setTimeout(() => {
                if (popup.parentElement) {
                    popup.remove();
                }
            }, 300);
        };

        closeBtn.addEventListener('click', closePopup);

        this.container.appendChild(popup);

        if (duration > 0) {
            setTimeout(closePopup, duration);
        }

        return popup;
    }

    // Specific popup methods
    addedToCart(itemName) {
        return this.show('ITEM ACQUIRED', `${itemName} has been added to your inventory`, 3000);
    }

    signedIn(userName) {
        return this.show('WELCOME BACK', `Thank you for signing in, ${userName}`, 4000);
    }

    welcome() {
        return this.show('WELCOME TO THE GUILD', 'Prepare for the hunt. Choose your relics wisely.', 5000);
    }

    // Generic methods
    success(message) { return this.show('SUCCESS', message, 3000); }
    error(message) { return this.show('ERROR', message, 5000); }
    info(message) { return this.show('NOTICE', message, 4000); }
    warning(message) { return this.show('WARNING', message, 4500); }
}

// Initialize popup system
const eldenPopup = new EldenPopup();

// =============================
// DYNAMIC SIGN IN/PROFILE LOGO
// =============================

function updateSignInLogo() {
    const isLoggedIn = localStorage.getItem('isLoggedIn');
    const signinLogo = document.querySelector('.signin-logo');
    const currentPage = window.location.pathname.split('/').pop() || 'index.html';
    
    // Don't run on signin page
    if (currentPage === 'signin.html') return;
    
    if (signinLogo) {
        if (isLoggedIn) {
            // User is logged in - show profile icon
            signinLogo.href = 'user-profile.html';
            signinLogo.title = 'Hunter Profile';
            signinLogo.innerHTML = `
                <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="#daa520" stroke-width="2">
                    <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"></path>
                    <circle cx="12" cy="7" r="4"></circle>
                </svg>
            `;
            signinLogo.style.background = 'rgba(218, 165, 32, 0.2)';
            signinLogo.style.borderColor = '#daa520';
        } else {
            // User is not logged in - show sign in icon
            signinLogo.href = 'signin.html';
            signinLogo.title = 'Enter Guild Hall';
            signinLogo.innerHTML = `
                <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="#daa520" stroke-width="2">
                    <path d="M15 3h4a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2h-4"></path>
                    <polyline points="10 17 15 12 10 7"></polyline>
                    <line x1="15" y1="12" x2="3" y2="12"></line>
                </svg>
            `;
            signinLogo.style.background = 'rgba(139, 69, 19, 0.2)';
            signinLogo.style.borderColor = '#8b4513';
        }
    }
}

// =============================
// MAIN PAGE FUNCTIONALITY
// =============================

document.addEventListener('DOMContentLoaded', function() {
    const bodyClass = document.body.className;
    const currentPage = window.location.pathname.split('/').pop() || 'index.html';

    // Update signin logo on all pages
    updateSignInLogo();

    // =============================
    // INDEX PAGE - WELCOME POPUP
    // =============================
    if (bodyClass.includes('index') || currentPage === 'index.html' || currentPage === '') {
        console.log('Index page detected - showing welcome popup');
        
        // Show welcome popup after a short delay
        setTimeout(() => {
            eldenPopup.welcome();
        }, 1000);

        // Sign-in detection for index page
        const isLoggedIn = localStorage.getItem('isLoggedIn');
        const userEmail = localStorage.getItem('userEmail');
        
        if (isLoggedIn && userEmail) {
            setTimeout(() => {
                const userName = userEmail.split('@')[0];
                eldenPopup.signedIn(userName);
            }, 2500);
        }
    }

    // =============================
    // PRODUCTS PAGE - ADD TO CART
    // =============================
    if (bodyClass.includes('products') || currentPage === 'products.html') {
        console.log('Products page detected - adding cart functionality');
        
        // Add to cart buttons for each product card
        const productCards = document.querySelectorAll('.product-card');
        productCards.forEach(card => {
            // Create add to cart button if it doesn't exist
            if (!card.querySelector('.add-to-cart-btn')) {
                const addButton = document.createElement('button');
                addButton.className = 'elden-popup-close add-to-cart-btn';
                addButton.textContent = 'ADD TO CART';
                addButton.style.marginTop = '1rem';
                addButton.style.width = '100%';
                
                // Get product name
                const productName = card.querySelector('.product-name')?.textContent || 'Ancient Relic';
                
                addButton.addEventListener('click', function() {
                    eldenPopup.addedToCart(productName);
                });
                
                card.appendChild(addButton);
            }
        });

        // Also attach to existing buttons that might be in the product content
        const existingButtons = document.querySelectorAll('.product-card a, .product-card button');
        existingButtons.forEach(button => {
            if (button.textContent.includes('View') || button.textContent.includes('Add') || button.href) {
                button.addEventListener('click', function(e) {
                    e.preventDefault();
                    const card = this.closest('.product-card');
                    const productName = card?.querySelector('.product-name')?.textContent || 'Ancient Relic';
                    eldenPopup.addedToCart(productName);
                    
                    // If it's a link, navigate after popup
                    if (this.href) {
                        setTimeout(() => {
                            window.location.href = this.href;
                        }, 1000);
                    }
                });
            }
        });
    }

    // =============================
    // SIGN IN PAGE - REDIRECT POPUP
    // =============================
    if (bodyClass.includes('signin') || currentPage === 'signin.html') {
        console.log('Sign in page detected - adding redirect popup');
        
        const signinForm = document.getElementById('signinForm');
        if (signinForm) {
            signinForm.addEventListener('submit', function(e) {
                e.preventDefault();
                
                const email = document.getElementById('email')?.value;
                const password = document.getElementById('password')?.value;
                const userName = email ? email.split('@')[0] : 'Hunter';
                
                if (!email || !password) {
                    eldenPopup.error('Complete the ancient rites to enter');
                    return;
                }
                
                // Show sign in success popup
                eldenPopup.signedIn(userName);
                
                // Store user data and redirect to PROFILE
                setTimeout(() => {
                    localStorage.setItem('isLoggedIn', 'true');
                    localStorage.setItem('userEmail', email);
                    localStorage.setItem('userName', userName);
                    localStorage.setItem('joinDate', new Date().toLocaleDateString());
                    window.location.href = 'user-profile.html';
                }, 1500);
            });
        }
    }

    // =============================
    // USER PROFILE PAGE - WELCOME BACK
    // =============================
    if (bodyClass.includes('userprofile') || currentPage === 'user-profile.html') {
        console.log('User profile page detected - showing welcome back');
        
        // Check if user is logged in
        const isLoggedIn = localStorage.getItem('isLoggedIn');
        const userEmail = localStorage.getItem('userEmail');
        
        if (!isLoggedIn || !userEmail) {
            // Redirect to sign in if not logged in
            setTimeout(() => {
                window.location.href = 'signin.html';
            }, 500);
            return;
        }
        
        // Populate profile data
        const userName = localStorage.getItem('userName') || userEmail.split('@')[0];
        const joinDate = localStorage.getItem('joinDate') || 'Recent';
        
        // Update profile elements
        const joinDateElement = document.getElementById('joinDate');
        if (joinDateElement) joinDateElement.textContent = joinDate;
        
        // Show welcome popup
        setTimeout(() => {
            eldenPopup.info(`Welcome to your hunter's lodge, ${userName}`);
        }, 1000);

        // Logout functionality
        const logoutBtn = document.getElementById('logoutBtn');
        if (logoutBtn) {
            logoutBtn.addEventListener('click', function() {
                localStorage.removeItem('isLoggedIn');
                localStorage.removeItem('userEmail');
                localStorage.removeItem('userName');
                localStorage.removeItem('joinDate');
                
                eldenPopup.info('You have left the guild hall. Return when ready.');
                
                setTimeout(() => {
                    window.location.href = 'index.html';
                }, 1500);
            });
        }
    }

    // Update logo when storage changes (if user signs in/out in another tab)
    window.addEventListener('storage', function(e) {
        if (e.key === 'isLoggedIn') {
            updateSignInLogo();
        }
    });
});

// =============================
// ELDEN RING SEARCH ENGINE
// =============================

class EldenSearch {
    constructor() {
        this.products = [
            { id: 1, name: 'DRAGONSBANE LONGSWORD', category: 'WEAPONS', price: 'R900,000', description: 'Legendary wyrm-tempered blade forged in ancient fires', rarity: 'LEGENDARY' },
            { id: 2, name: 'CHRONOBLADE', category: 'WEAPONS', price: 'R1,200,000', description: 'Time manipulation weapon that slows reality', rarity: 'EPIC' },
            { id: 3, name: 'WHISPERBOW', category: 'WEAPONS', price: 'R750,000', description: 'Stealth mechanics weapon for silent hunting', rarity: 'RARE' },
            { id: 4, name: 'RAGING WOLF ARMOR SET', category: 'ARMOR', price: 'R850,000', description: 'Best armor for Shadow Realm exploration', rarity: 'EPIC' },
            { id: 5, name: 'WARDEN\'S PLATE ARMOR', category: 'ARMOR', price: 'R950,000', description: 'High defensive stats armor with runic protection', rarity: 'RARE' },
            { id: 6, name: 'SHADOW REALM GUIDE', category: 'GUIDES', price: 'R150,000', description: 'Complete exploration guide for the cursed lands', rarity: 'COMMON' },
            { id: 7, name: 'DRAGONBONE WEAPONS COLLECTION', category: 'WEAPONS', price: 'R1,500,000', description: 'Forged from ancient dragon remains', rarity: 'LEGENDARY' },
            { id: 8, name: 'DEATH DRAGON BOSS FIGHT GUIDE', category: 'GUIDES', price: 'R200,000', description: 'Gameplay guide for ancient boss fights', rarity: 'COMMON' },
            { id: 9, name: 'SOULBINDER WHIP', category: 'WEAPONS', price: 'R850,000', description: 'Latches onto spirit energy', rarity: 'EXOTIC' },
            { id: 10, name: 'ECLIPSE SCYTHE', category: 'WEAPONS', price: 'R900,000', description: 'Harvests souls in moonlight', rarity: 'EPIC' },
            { id: 11, name: 'CELESTIAL HAMMER', category: 'WEAPONS', price: 'R900,000', description: 'Calls down starlight upon foes', rarity: 'LEGENDARY' }
        ];
        this.init();
    }

    init() {
        this.setupSearchForms();
        this.createSearchContainer();
    }

    setupSearchForms() {
        const searchForms = document.querySelectorAll('form[role="search"]');
        searchForms.forEach(form => {
            form.addEventListener('submit', (e) => {
                e.preventDefault();
                const input = form.querySelector('input[type="search"]');
                this.performSearch(input.value.trim());
            });
        });

        // Real-time search as you type
        const searchInputs = document.querySelectorAll('input[type="search"]');
        searchInputs.forEach(input => {
            input.addEventListener('input', (e) => {
                if (e.target.value.length > 2) {
                    this.performSearch(e.target.value.trim());
                } else if (e.target.value.length === 0) {
                    this.clearSearchResults();
                }
            });
        });
    }

    createSearchContainer() {
        // Create search results container if it doesn't exist
        if (!document.getElementById('searchResults')) {
            const container = document.createElement('div');
            container.id = 'searchResults';
            container.className = 'elden-search-results';
            
            // Insert at the beginning of main content
            const main = document.querySelector('main');
            if (main) {
                main.insertBefore(container, main.firstChild);
            }
        }
    }

    performSearch(query) {
        if (!query) {
            this.clearSearchResults();
            return;
        }

        const results = this.products.filter(product =>
            product.name.toLowerCase().includes(query.toLowerCase()) ||
            product.category.toLowerCase().includes(query.toLowerCase()) ||
            product.description.toLowerCase().includes(query.toLowerCase()) ||
            product.rarity.toLowerCase().includes(query.toLowerCase())
        );

        this.displayResults(results, query);
    }

    displayResults(results, query) {
        const resultsContainer = document.getElementById('searchResults');
        if (!resultsContainer) return;

        if (results.length === 0) {
            resultsContainer.innerHTML = this.getNoResultsHTML(query);
            eldenPopup.warning(`No relics found for "${query}"`);
            return;
        }

        resultsContainer.innerHTML = this.getResultsHTML(results, query);
        this.addResultEventListeners();
        
        // Scroll to results
        resultsContainer.scrollIntoView({ behavior: 'smooth', block: 'start' });
        
        eldenPopup.info(`Found ${results.length} relic${results.length > 1 ? 's' : ''} for "${query}"`);
    }

    clearSearchResults() {
        const resultsContainer = document.getElementById('searchResults');
        if (resultsContainer) {
            resultsContainer.innerHTML = '';
        }
    }

    getNoResultsHTML(query) {
        return `
            <div class="elden-search-empty">
                <div class="empty-title">NO RELICS FOUND</div>
                <div class="empty-message">Your search for "${query}" revealed nothing in the archives</div>
                <div class="empty-suggestion">Try searching for: Weapons, Armor, Legendary, Rare, Epic</div>
            </div>
        `;
    }

    getResultsHTML(results, query) {
        return `
            <div class="elden-search-header">
                <div class="search-title">ARCHIVES OF THE GREATER HUNT</div>
                <div class="search-subtitle">Found ${results.length} relic${results.length > 1 ? 's' : ''} for "${query}"</div>
            </div>
            <div class="elden-results-grid">
                ${results.map(product => `
                    <div class="elden-result-card" data-product-id="${product.id}">
                        <div class="result-rarity ${product.rarity.toLowerCase()}">${product.rarity}</div>
                        <div class="result-name">${product.name}</div>
                        <div class="result-category">${product.category}</div>
                        <div class="result-description">${product.description}</div>
                        <div class="result-price">${product.price}</div>
                        <button class="add-to-cart-btn" data-product='${JSON.stringify(product).replace(/'/g, "&apos;")}'>ADD TO CART</button>
                    </div>
                `).join('')}
            </div>
        `;
    }

    addResultEventListeners() {
        // Add to cart buttons
        document.querySelectorAll('.add-to-cart-btn').forEach(button => {
            button.addEventListener('click', (e) => {
                const product = JSON.parse(e.target.dataset.product);
                eldenPopup.addedToCart(product.name);
            });
        });

        // View item details on card click
        document.querySelectorAll('.elden-result-card').forEach(card => {
            card.addEventListener('click', (e) => {
                if (!e.target.classList.contains('add-to-cart-btn')) {
                    const productId = card.dataset.productId;
                    const product = this.products.find(p => p.id == productId);
                    if (product) {
                        eldenPopup.show(
                            product.name,
                            `${product.description}<br><br>Category: ${product.category}<br>Rarity: ${product.rarity}<br>Price: ${product.price}`,
                            0
                        );
                    }
                }
            });
        });
    }
}

// Initialize search system
const eldenSearch = new EldenSearch();

// Add search functionality to existing search forms
document.addEventListener('DOMContentLoaded', function() {
    // Auto-focus search input when search form is clicked
    document.querySelectorAll('form[role="search"]').forEach(form => {
        form.addEventListener('click', function() {
            const input = this.querySelector('input[type="search"]');
            if (input) input.focus();
        });
    });
});

// Thank you popup for Seal Pact button
function addPactPopup() {
    // Find all Seal Pact buttons
    const pactButtons = document.querySelectorAll('button, input[type="submit"], a');
    
    pactButtons.forEach(button => {
        if (button.textContent.toLowerCase().includes('seal pact') || 
            button.textContent.toLowerCase().includes('seal the pact') ||
            button.value.toLowerCase().includes('seal pact')) {
            
            button.addEventListener('click', function(e) {
                // Only show popup if it's not already showing
                if (!document.getElementById('pactPopup')) {
                    showPactPopup();
                }
            });
        }
    });
}

function showPactPopup() {
    // Create popup overlay
    const popupOverlay = document.createElement('div');
    popupOverlay.id = 'pactPopup';
    popupOverlay.style.cssText = `
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background: rgba(0, 0, 0, 0.8);
        display: flex;
        justify-content: center;
        align-items: center;
        z-index: 10000;
        font-family: inherit;
    `;
    
    // Create popup content
    const popupContent = document.createElement('div');
    popupContent.style.cssText = `
        background: linear-gradient(135deg, #1a150e 0%, #2a2418 100%);
        border: 3px solid #daa520;
        border-radius: 10px;
        padding: 30px;
        text-align: center;
        max-width: 400px;
        box-shadow: 0 0 30px rgba(218, 165, 32, 0.5);
        color: #e0d3b8;
    `;
    
    popupContent.innerHTML = `
        <h2 style="color: #daa520; margin-bottom: 20px; font-size: 1.8rem;">Pact Sealed! 🎉</h2>
        <p style="font-size: 1.1rem; margin-bottom: 25px; line-height: 1.5;">
            Thank you for making a pact with The Greater Hunt. Your loyalty has been recorded in the Guild Chronicles.
        </p>
        <button id="closePopup" style="
            background: linear-gradient(to bottom, #8b4513, #5d4037);
            border: 2px solid #daa520;
            color: #e6d3a3;
            padding: 12px 30px;
            font-size: 1.1rem;
            border-radius: 5px;
            cursor: pointer;
            transition: all 0.3s ease;
        ">Continue Journey</button>
    `;
    
    popupOverlay.appendChild(popupContent);
    document.body.appendChild(popupOverlay);
    
    // Close popup when button clicked
    document.getElementById('closePopup').addEventListener('click', function() {
        document.body.removeChild(popupOverlay);
    });
    
    // Close popup when clicking outside
    popupOverlay.addEventListener('click', function(e) {
        if (e.target === popupOverlay) {
            document.body.removeChild(popupOverlay);
        }
    });
}

// Initialize when page loads
document.addEventListener('DOMContentLoaded', function() {
    addPactPopup();
});

// Add this to your products.js or existing JavaScript file
function addToCart(product) {
    let cart = JSON.parse(localStorage.getItem('cart')) || [];
    
    // Check if product already in cart
    const existingItem = cart.find(item => item.id === product.id);
    
    if (existingItem) {
        existingItem.quantity += 1;
    } else {
        cart.push({
            id: product.id,
            name: product.name,
            price: product.price,
            image: product.image,
            quantity: 1
        });
    }
    
    localStorage.setItem('cart', JSON.stringify(cart));
    
    // Show success message
    alert(`${product.name} added to cart!`);
    
    // Update cart count in navigation (if you have one)
    updateCartCount();
}

function updateCartCount() {
    const cart = JSON.parse(localStorage.getItem('cart')) || [];
    const totalItems = cart.reduce((sum, item) => sum + item.quantity, 0);
    
    // Update cart count in navigation
    const cartCount = document.getElementById('cartCount');
    if (cartCount) {
        cartCount.textContent = totalItems;
    }
}

// Example product data structure
const products = {
    1: {
        id: 1,
        name: "Dragonsbane Longsword",
        price: "R900,000",
        image: "images/THE BANE SWORD.jpg"
    },
    2: {
        id: 2,
        name: "Whisperbow", 
        price: "R1,000,000",
        image: "images/WIND BOW.jpg"
    }
    // Add more products...
};








/*KJWBHJFBWEGFYGJKBFIJBFC */

// Wagon Popup Functionality
class WagonPopup {
    constructor() {
        this.popup = document.getElementById('wagonPopup');
        this.init();
    }

    init() {
        // Close popup when clicking outside
        this.popup.addEventListener('click', (e) => {
            if (e.target === this.popup) {
                this.close();
            }
        });

        // Close popup with Escape key
        document.addEventListener('keydown', (e) => {
            if (e.key === 'Escape' && this.popup.style.display === 'flex') {
                this.close();
            }
        });
    }

    show(product) {
        this.updatePopupContent(product);
        this.popup.style.display = 'flex';
        document.body.style.overflow = 'hidden';
        
        // Add success class for visual feedback
        this.popup.querySelector('.elden-popup').classList.add('popup-success');
    }

    close() {
        const popupContent = this.popup.querySelector('.elden-popup');
        popupContent.classList.add('popup-closing');
        
        setTimeout(() => {
            this.popup.style.display = 'none';
            popupContent.classList.remove('popup-closing', 'popup-success');
            document.body.style.overflow = '';
        }, 300);
    }

    updatePopupContent(product) {
        const cart = JSON.parse(localStorage.getItem('eldenCart')) || [];
        
        // Update item details
        document.getElementById('popupItemImage').src = product.image;
        document.getElementById('popupItemImage').alt = product.name;
        document.getElementById('popupItemName').textContent = product.name;
        document.getElementById('popupItemPrice').textContent = product.price;

        // Update cart stats
        const totalItems = cart.reduce((sum, item) => sum + item.quantity, 0);
        const totalPrice = cart.reduce((sum, item) => {
            const price = this.extractRunes(item.price);
            return sum + (price * item.quantity);
        }, 0);

        document.getElementById('popupItemCount').textContent = totalItems;
        document.getElementById('popupTotalPrice').textContent = `${totalPrice} Runes`;
    }

    extractRunes(priceString) {
        const numericString = priceString.replace(/[^0-9]/g, '');
        return parseInt(numericString) || 0;
    }
}

// Global functions for HTML onclick attributes
function closeWagonPopup() {
    wagonPopup.close();
}

function goToWagon() {
    wagonPopup.close();
    setTimeout(() => {
        window.location.href = 'cart.html';
    }, 300);
}

// Enhanced addToCart function with popup
function addToCartWithPopup(product) {
    const cartSystem = new CartSystem();
    let cart = cartSystem.cart;
    
    const existingItem = cart.find(item => item.id === product.id);
    
    if (existingItem) {
        existingItem.quantity += 1;
    } else {
        cart.push({
            id: product.id,
            name: product.name,
            price: product.price,
            image: product.image,
            description: product.description,
            quantity: 1
        });
    }
    
    localStorage.setItem('eldenCart', JSON.stringify(cart));
    
    // Show the wagon popup
    wagonPopup.show(product);
    
    // Update cart count
    cartSystem.updateCartCount();
}

// Initialize wagon popup
const wagonPopup = new WagonPopup();

// Update your existing addToCart function in products page
function addToCart(product) {
    addToCartWithPopup(product);
}